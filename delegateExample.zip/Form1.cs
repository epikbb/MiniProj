﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace delegateExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.ucTree1.IClicked += new MyClickEventHandler(UcTree1_IClicked);
        }

        private void UcTree1_IClicked(string Message)
        {
            try
            {
                this.ucModel1.textBox1.Text = Message;
                this.ucModel1.Icalled(Message);
            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
        }
    }
}
